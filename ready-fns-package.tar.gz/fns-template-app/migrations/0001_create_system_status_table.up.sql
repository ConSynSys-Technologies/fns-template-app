CREATE TABLE system_status (id integer PRIMARY KEY AUTOINCREMENT, system_id TEXT, status integer, timestamp TEXT);
