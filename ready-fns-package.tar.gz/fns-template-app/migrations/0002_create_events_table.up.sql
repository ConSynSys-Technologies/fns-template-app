CREATE TABLE events (id integer PRIMARY KEY AUTOINCREMENT, system_id TEXT, attribute_id TEXT, root TEXT, instrument TEXT, attribute TEXT, state TEXT, timestamp TEXT);
