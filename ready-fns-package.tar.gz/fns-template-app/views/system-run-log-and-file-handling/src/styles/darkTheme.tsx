import { createTheme } from "@mui/material";

const theme = createTheme({})

export default theme;